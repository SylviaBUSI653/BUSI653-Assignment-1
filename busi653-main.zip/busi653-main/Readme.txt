This is a project for BUSI653!
Have fun hosting your personal website on the Cloud!
